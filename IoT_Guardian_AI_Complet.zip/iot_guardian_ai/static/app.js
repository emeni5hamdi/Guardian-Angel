const devicesContainer = document.getElementById("devices");
const historySelect = document.getElementById("history-device");
const historyBody = document.getElementById("history-body");
let knownDevices = [];

function displayValue(value, suffix = "") {
    return value === null || value === undefined ? "—" : `${value}${suffix}`;
}

function statusClass(status) {
    return status === "HORS LIGNE" ? "OFFLINE" : status;
}

async function loadDevices() {
    try {
        const response = await fetch("/api/devices");
        const devices = await response.json();
        if (!response.ok) throw new Error(devices.error || "Erreur API");

        knownDevices = devices;
        devicesContainer.innerHTML = "";

        let active = 0;
        let offline = 0;
        let alertCount = 0;

        devices.forEach(device => {
            if (device.status === "HORS LIGNE") offline++;
            else active++;
            if (device.status === "ALERTE" || device.status === "HORS LIGNE") alertCount++;

            const card = document.createElement("article");
            card.className = `device-card ${statusClass(device.status)}`;
            card.innerHTML = `
                <div class="card-head">
                    <div>
                        <h3>${device.name}</h3>
                        <div class="muted">${device.location} • ${device.code}</div>
                    </div>
                    <span class="badge">${device.status}</span>
                </div>
                <div class="metrics">
                    <div class="metric"><strong>${displayValue(device.temperature, "°C")}</strong><small>Température</small></div>
                    <div class="metric"><strong>${displayValue(device.humidity, "%")}</strong><small>Humidité</small></div>
                    <div class="metric"><strong>${displayValue(device.battery, "%")}</strong><small>Batterie</small></div>
                </div>
                <div class="muted">Dernière mesure : ${device.recorded_at ? new Date(device.recorded_at).toLocaleString() : "jamais"}</div>
                ${device.alerts.length ? `<ul class="alert-list">${device.alerts.map(a => `<li>${a}</li>`).join("")}</ul>` : ""}
            `;
            devicesContainer.appendChild(card);
        });

        document.getElementById("count-total").textContent = devices.length;
        document.getElementById("count-active").textContent = active;
        document.getElementById("count-offline").textContent = offline;
        document.getElementById("count-alerts").textContent = alertCount;
        document.getElementById("last-refresh").textContent = `Dernière actualisation : ${new Date().toLocaleTimeString()}`;
        refreshHistoryOptions(devices);
    } catch (error) {
        devicesContainer.innerHTML = `<p>Erreur: ${error.message}. Vérifie que Flask et MySQL sont démarrés.</p>`;
    }
}

function refreshHistoryOptions(devices) {
    const current = historySelect.value;
    historySelect.innerHTML = devices.map(d => `<option value="${d.code}">${d.name}</option>`).join("");
    if (devices.some(d => d.code === current)) historySelect.value = current;
}

async function loadHistory() {
    const code = historySelect.value;
    if (!code) return;

    try {
        const response = await fetch(`/api/history/${encodeURIComponent(code)}`);
        const rows = await response.json();
        if (!response.ok) throw new Error(rows.error || "Erreur historique");

        historyBody.innerHTML = rows.length ? rows.map(row => `
            <tr>
                <td>${new Date(row.recorded_at).toLocaleString()}</td>
                <td>${row.temperature} °C</td>
                <td>${row.humidity} %</td>
                <td>${row.battery} %</td>
            </tr>
        `).join("") : `<tr><td colspan="4">Aucune mesure.</td></tr>`;
    } catch (error) {
        historyBody.innerHTML = `<tr><td colspan="4">${error.message}</td></tr>`;
    }
}

document.getElementById("load-history").addEventListener("click", loadHistory);
loadDevices();
setInterval(loadDevices, 4000);
