from datetime import datetime, timezone

from flask import Flask, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error

from config import (
    DB_CONFIG,
    TEMP_ALERT,
    HUMIDITY_ALERT,
    BATTERY_ALERT,
    OFFLINE_AFTER_SECONDS,
)

app = Flask(__name__)


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


def calculate_alerts(temperature, humidity, battery):
    alerts = []
    if temperature >= TEMP_ALERT:
        alerts.append("Température élevée")
    if humidity >= HUMIDITY_ALERT:
        alerts.append("Humidité élevée")
    if battery <= BATTERY_ALERT:
        alerts.append("Batterie faible")
    return alerts


def seconds_since(timestamp):
    if timestamp is None:
        return None

    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    return max(0, int((now - timestamp).total_seconds()))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/measurements", methods=["POST"])
def create_measurement():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Le corps JSON est obligatoire."}), 400

    required = ["device_id", "temperature", "humidity", "battery"]
    missing = [field for field in required if field not in data]
    if missing:
        return jsonify({"error": f"Champs manquants: {', '.join(missing)}"}), 400

    try:
        code = str(data["device_id"]).strip().upper()
        temperature = float(data["temperature"])
        humidity = float(data["humidity"])
        battery = int(data["battery"])
    except (TypeError, ValueError):
        return jsonify({"error": "Types de données invalides."}), 400

    if not code:
        return jsonify({"error": "device_id vide."}), 400
    if not (-50 <= temperature <= 100):
        return jsonify({"error": "Température hors plage autorisée."}), 400
    if not (0 <= humidity <= 100):
        return jsonify({"error": "Humidité doit être entre 0 et 100."}), 400
    if not (0 <= battery <= 100):
        return jsonify({"error": "Batterie doit être entre 0 et 100."}), 400

    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("SELECT id, code, name, location FROM devices WHERE code = %s", (code,))
        device = cursor.fetchone()
        if not device:
            return jsonify({"error": f"Capteur inconnu: {code}"}), 404

        cursor.execute(
            """
            INSERT INTO readings (device_id, temperature, humidity, battery)
            VALUES (%s, %s, %s, %s)
            """,
            (device["id"], temperature, humidity, battery),
        )
        connection.commit()

        alerts = calculate_alerts(temperature, humidity, battery)
        status = "ALERTE" if alerts else "NORMAL"

        return jsonify(
            {
                "message": "Mesure enregistrée.",
                "device": device,
                "status": status,
                "alerts": alerts,
            }
        ), 201
    except Error as exc:
        return jsonify({"error": f"Erreur MySQL: {exc}"}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


@app.route("/api/devices", methods=["GET"])
def get_devices():
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(
            """
            SELECT
                d.id,
                d.code,
                d.name,
                d.location,
                r.temperature,
                r.humidity,
                r.battery,
                r.recorded_at
            FROM devices d
            LEFT JOIN readings r ON r.id = (
                SELECT r2.id
                FROM readings r2
                WHERE r2.device_id = d.id
                ORDER BY r2.recorded_at DESC, r2.id DESC
                LIMIT 1
            )
            ORDER BY d.id
            """
        )
        rows = cursor.fetchall()

        result = []
        for row in rows:
            last_seen_seconds = seconds_since(row["recorded_at"])

            if row["recorded_at"] is None:
                status = "HORS LIGNE"
                alerts = ["Aucune mesure reçue"]
            elif last_seen_seconds > OFFLINE_AFTER_SECONDS:
                status = "HORS LIGNE"
                alerts = ["Appareil hors ligne"]
            else:
                temperature = float(row["temperature"])
                humidity = float(row["humidity"])
                battery = int(row["battery"])
                alerts = calculate_alerts(temperature, humidity, battery)
                status = "ALERTE" if alerts else "NORMAL"

            result.append(
                {
                    "code": row["code"],
                    "name": row["name"],
                    "location": row["location"],
                    "temperature": float(row["temperature"]) if row["temperature"] is not None else None,
                    "humidity": float(row["humidity"]) if row["humidity"] is not None else None,
                    "battery": int(row["battery"]) if row["battery"] is not None else None,
                    "recorded_at": row["recorded_at"].isoformat() if row["recorded_at"] else None,
                    "last_seen_seconds": last_seen_seconds,
                    "status": status,
                    "alerts": alerts,
                }
            )

        return jsonify(result)
    except Error as exc:
        return jsonify({"error": f"Erreur MySQL: {exc}"}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


@app.route("/api/history/<code>", methods=["GET"])
def get_history(code):
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("SELECT id FROM devices WHERE code = %s", (code.upper(),))
        device = cursor.fetchone()
        if not device:
            return jsonify({"error": "Capteur introuvable."}), 404

        cursor.execute(
            """
            SELECT temperature, humidity, battery, recorded_at
            FROM readings
            WHERE device_id = %s
            ORDER BY recorded_at DESC, id DESC
            LIMIT 12
            """,
            (device["id"],),
        )
        rows = cursor.fetchall()

        history = [
            {
                "temperature": float(row["temperature"]),
                "humidity": float(row["humidity"]),
                "battery": int(row["battery"]),
                "recorded_at": row["recorded_at"].isoformat(),
            }
            for row in rows
        ]
        return jsonify(history)
    except Error as exc:
        return jsonify({"error": f"Erreur MySQL: {exc}"}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
