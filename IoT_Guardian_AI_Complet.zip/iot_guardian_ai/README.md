# IoT Guardian AI - Prototype local V1

## Fonctionnement
- `simulateur.py` simule SALON, CUISINE et GARAGE.
- Les données sont envoyées en HTTP + JSON vers Flask.
- `app.py` valide puis enregistre les mesures dans MySQL.
- Le dashboard appelle l'API toutes les 4 secondes.
- Alertes : température >= 40°C, humidité >= 85%, batterie <= 20%, hors ligne après plus de 20 secondes sans message.

## Installation Windows + XAMPP
1. Installer XAMPP et Python 3.
2. Ouvrir XAMPP Control Panel.
3. Démarrer MySQL. Apache est utile uniquement pour phpMyAdmin.
4. Aller dans `http://localhost/phpmyadmin`.
5. Onglet **Importer** puis sélectionner `database.sql`.
6. Ouvrir PowerShell/CMD dans ce dossier.
7. Exécuter : `py -m pip install -r requirements.txt`
8. Terminal 1 : `py app.py`
9. Terminal 2 : `py simulateur.py`
10. Ouvrir `http://127.0.0.1:5000`

## Si MySQL root a un mot de passe
Modifier `config.py` et mettre le mot de passe dans `DB_CONFIG["password"]`.
