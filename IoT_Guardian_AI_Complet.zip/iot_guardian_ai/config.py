DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "iot_guardian_ai",
    "port": 3306,
}

TEMP_ALERT = 40.0
HUMIDITY_ALERT = 85.0
BATTERY_ALERT = 20
OFFLINE_AFTER_SECONDS = 20
