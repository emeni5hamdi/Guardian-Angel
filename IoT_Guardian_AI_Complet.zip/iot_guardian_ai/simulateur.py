import random
import time

import requests

API_URL = "http://127.0.0.1:5000/api/measurements"
SEND_EVERY_SECONDS = 5

batteries = {
    "SALON": 95,
    "CUISINE": 88,
    "GARAGE": 72,
}


def send_measurement(device_id, temperature, humidity, battery):
    payload = {
        "device_id": device_id,
        "temperature": round(temperature, 1),
        "humidity": round(humidity, 1),
        "battery": battery,
    }

    try:
        response = requests.post(API_URL, json=payload, timeout=3)
        print(f"{device_id} -> {payload} -> HTTP {response.status_code}")
        if response.content:
            print(response.json())
    except requests.RequestException as exc:
        print(f"Impossible de joindre Flask: {exc}")


def reduce_battery(device_id):
    if random.random() < 0.20:
        batteries[device_id] = max(5, batteries[device_id] - 1)


def main():
    print("Simulateur IoT Guardian AI démarré.")
    print("Ctrl+C pour arrêter.")

    cycle = 0
    while True:
        cycle += 1
        print(f"\n--- Cycle {cycle} ---")

        reduce_battery("SALON")
        send_measurement(
            "SALON",
            random.uniform(22.0, 26.0),
            random.uniform(45.0, 60.0),
            batteries["SALON"],
        )

        reduce_battery("CUISINE")
        kitchen_overheat = cycle % 5 == 0 or random.random() < 0.15
        kitchen_temp = random.uniform(42.0, 48.0) if kitchen_overheat else random.uniform(24.0, 30.0)
        send_measurement(
            "CUISINE",
            kitchen_temp,
            random.uniform(50.0, 70.0),
            batteries["CUISINE"],
        )

        # Le garage est volontairement silencieux pendant 5 cycles,
        # soit environ 25 secondes, afin de déclencher le statut HORS LIGNE (>20 s).
        garage_silent = 7 <= (cycle % 12) <= 11
        if garage_silent:
            print("GARAGE -> aucune donnée envoyée (simulation de coupure réseau)")
        else:
            reduce_battery("GARAGE")
            send_measurement(
                "GARAGE",
                random.uniform(18.0, 27.0),
                random.uniform(40.0, 65.0),
                batteries["GARAGE"],
            )

        time.sleep(SEND_EVERY_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nSimulateur arrêté.")
