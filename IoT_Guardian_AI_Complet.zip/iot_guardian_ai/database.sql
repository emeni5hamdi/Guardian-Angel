CREATE DATABASE IF NOT EXISTS iot_guardian_ai
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE iot_guardian_ai;

DROP TABLE IF EXISTS readings;
DROP TABLE IF EXISTS devices;

CREATE TABLE devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    device_id INT NOT NULL,
    temperature DECIMAL(5,2) NOT NULL,
    humidity DECIMAL(5,2) NOT NULL,
    battery INT NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_readings_device
        FOREIGN KEY (device_id) REFERENCES devices(id)
        ON DELETE CASCADE
);

INSERT INTO devices (code, name, location) VALUES
('SALON', 'Capteur Salon', 'Salon'),
('CUISINE', 'Capteur Cuisine', 'Cuisine'),
('GARAGE', 'Capteur Garage', 'Garage');
